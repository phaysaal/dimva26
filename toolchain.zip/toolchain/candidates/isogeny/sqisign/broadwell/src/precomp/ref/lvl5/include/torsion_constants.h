#include <quaternion.h>
#define TORSION_2POWER_BYTES 63
extern const ibz_t TWO_TO_SECURITY_BITS;
extern const ibz_t TORSION_PLUS_2POWER;
extern const ibz_t SEC_DEGREE;
extern const ibz_t COM_DEGREE;
