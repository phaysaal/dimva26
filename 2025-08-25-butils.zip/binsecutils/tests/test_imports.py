# --------------------
import pytest
import importlib
# --------------------
MODULES = [
    'binsecutils.binary',
    'binsecutils.binsec',
    'binsecutils.cli',
    'binsecutils.auto.utils',
    'binsecutils.auto.resources',
    'binsecutils.auto.pqc1',
    'binsecutils.auto.autodisasm',
    'binsecutils.auto',
    'binsecutils',
]
# --------------------
@pytest.mark.parametrize('module', MODULES)
def test_import(module):
    importlib.import_module(module)
# --------------------
