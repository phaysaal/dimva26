# --------------------
import os
import io
import re
import sys
import copy
import tempfile
import logging
import importlib.resources
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, TypedDict, Callable, TextIO
from typing_extensions import NotRequired
from .._intracore.system import command_exec, ExecResult
from ..binary import BinsecBinaryFile
from . import resources
from .utils import create_tempfile as _create_tempfile
# --------------------
def pqc1_coredump(bf: str) -> str:
    # 1. Detect binary file and gdb script file
    if bf.endswith('.snapshot'):
        bf = os.path.splitext(bf)[0]
    logging.info('applying pqc1 to %s', bf)
    gdbf = f'{bf}.gdb'
    # 2. Patch coredump generation
    if not os.path.isfile(gdbf):
        logging.error('pqc1 cannot be applied because gdb file %s does not exist', gdbf)
        raise FileNotFoundError(gdbf)
    with open(gdbf) as stream:
        gdb_script = stream.read()
    snapshot_fname = f'{bf}.snapshot'
    # 2.A Get target
    rmatch = re.search(r'generate-core-file\s+(\S+)\s', gdb_script)
    if not rmatch:
        logging.error('pqc1 cannot be applied because gdb file %s does not produce any snapshot', gdbf)
        raise ValueError(gdbf)
    elif rmatch[1] != snapshot_fname:
        logging.warning('pqc1: gdb file %s does not originally produce %s.snapshot but %s', gdbf, bf, snapshot_fname)
        snapshot_fname = rmatch[1]
    # 2.B Get analysis target
    fcall = None
    try:
        logging.info('pqc1 loading binary file %s', bf)
        bfdata = BinsecBinaryFile(bf)
        thcalls, thoffsets = bfdata.calls_of('main')
        duals = [symbol for symbol, count in thcalls.items() if count == 2]
        if len(duals) == 1:
            fcall = duals[0]
        elif len(duals) > 1:
            logging.warning('pqc1 found more than one double call in main symbol, choosing one')
            sanitized_duals = [d for d in duals if not d.startswith('__')]
            fcall = sanitized_duals[0] if sanitized_duals else duals[0]
        else:
            logging.warning('pqc1 found no double call in main symbol -> fallback')
        if '+' in fcall:
            logging.warning('relative function call -> trying address based breakpoint setting')
            fcall = f'*(main+{thoffsets[fcall][-1]})'
    except (OSError, KeyError):
        logging.warning('pqc1 failed to load binary file %s', bf)
    if fcall is None:
        logging.warning('trying pqc1 name based target detection')
        for pfc in ('crypto_sign_keypair', 'crypto_sign'):
            if f'test_harness_{pfc}' in bf:
                fcall = pfc
                break
    if fcall is None:
        logging.error('pqc1 cannot be applied because no test harness function were found from filename')
        raise ValueError(fcall)
    logging.info('setting pqc1 target call to %s', fcall)
    snapshot = _create_tempfile()
    logging.info('setting pqc1 coredump file to %s', snapshot)
    # 2.C Patching
    for mark, patch in {'break main\n': f'break {fcall}\n', 'start\n': 'start\ncontinue\n' if fcall.startswith('*') else 'start\ncontinue\ncontinue\n',
                        snapshot_fname: snapshot}.items():
        if gdb_script.count(mark) != 1:
            logging.error('pqc1 cannot be applied because the gdb script is incompatible')
            raise ValueError(mark)
        gdb_script = gdb_script.replace(mark, patch)
    gdb_rerun = _create_tempfile()
    logging.info('setting pqc1 coredump script file file to %s', gdb_rerun)
    with open(gdb_rerun, 'wt') as stream:
        stream.write(gdb_script)
    # 2.D Generating coredump
    gdb_cmd = ['gdb', '-x', gdb_rerun, bf]
    logging.info('running pqc1 gdb command: %s', ' '.join(gdb_cmd))
    res = command_exec(gdb_cmd, timeout=60)
    if res.rv != 0:
        logging.error('pqc1 cannot be applied because the coredump generation failed')
        raise ValueError(res)
    return snapshot
# --------------------
def pqc2_coredump(bf: str) -> str:
    gdbf = _create_tempfile()
    snapshot = _create_tempfile()
    cf = os.path.join(os.path.split(bf)[0], 'taint_crypto_sign.c')
    cl = 0
    tgt = None
    if not os.path.isfile(cf):
        logging.error(f'pqc2 cannot be applied because timecop source ({cf}) cannot be found')
    with open(cf, 'r') as stream:
        for line in stream:
            cl += 1
            if line.strip().startswith('wxf_poison'):
                tgt = cl
    if tgt is None:
        logging.error('pqc2 cannot be applied because timecop source does not call the <poison> wrapper; did you apply the toolchain patch?')
        raise ValueError(tgt)
    if tgt != 33:
        logging.warning(f'pqc2 application may be unsafe because crypto_sign call line is not 33: {tgt}')
    with open(gdbf, 'w') as stream:
        stream.write('set pagination off\nset env LD_BIND_NOW=1\nset env GLIBC_TUNABLES=glibc.cpu.hwcaps=-AVX2_Usable\n')
        stream.write(f'b main\nstart\nb {tgt}\nc\n')  # TODO: This is the maximal level of unsafe
        stream.write(f'generate-core-file {snapshot}\nkill\nquit\n')
        # 2.D Generating coredump
    gdb_cmd = ['gdb', '-x', gdbf, bf]
    logging.info('running pqc2 gdb command: %s', ' '.join(gdb_cmd))
    res = command_exec(gdb_cmd, timeout=60)
    if res.rv != 0:
        logging.error('pqc1 cannot be applied because the coredump generation failed')
        raise ValueError(res)
    return snapshot
# --------------------
_EMERGENCY_PQC2_MINICFG = '''
starting from core
replace <wxf_poison>(sk, sz) by
    for i<64> in 0 to sz do
        @[sk + i] := secret
    end
    return
end
replace <wxf_unpoison>(sk, size) by
    return
end
halt at <exit>
explore all
'''
def pqc2_script() -> str:
    script = _create_tempfile()
    with open(script, 'w') as stream:
        stream.write(_EMERGENCY_PQC2_MINICFG)
        stream.write('\n')
    return script
# --------------------
def _create_pqc1_stubs() -> dict[str, str]:
    stubs_data = []
    for subfile in ('stubs_avx2_vpblendd.ini',
                    'stubs_avx2_vpblendvb.ini',
                    'stubs_avx2_vpsllvq.ini',
                    'stubs_avx2_vpsrlvq.ini',
                    'stubs_avx2_vpermd.ini',
                    'stubs_const_aes.ini',
                    'stubs_others.ini',
                    #'stubs_nondet_stubs.ini',
                    #'stubs_nondet_vaes.ini',
                    #'stubs_nondet_vaeskeygenassist.ini'
                    ):
        with importlib.resources.open_text(resources, subfile) as stream:
            cstub = ''
            for line in stream:
                if line.strip().startswith('replace') and cstub:
                    stubs_data.append(cstub)
                    cstub = ''
                cstub += line
            if cstub:
                stubs_data.append(cstub)
    stubs = {}
    for stub in stubs_data:
        header = re.match(r'replace\s+opcode\s+([0-9a-f][0-9a-f ]+)by', stub)
        if header:
            opcode = header[1].replace(' ', '')
            if opcode in stubs:
                logging.debug('multiple pqc1 stubs for opcode %s in library', opcode)
            stubs[opcode] = stub
            logging.debug('found pqc1 stub for %s', opcode)
        else:
            logging.warning('malformed pqc1 stub in library: %s', stub.split('\n')[0])
    return stubs
# --------------------
def _create_pqc1_functions() -> dict[str, str]:
    stubs = {}
    for fname in (
        'calloc',
        'cfree',
        'randombytes'
    ):
        resource = f'stubs_{fname}.ini'
        content = importlib.resources.read_text(resources, resource)
        stubs[fname] = content
    return stubs
# --------------------
PQC1_STUBS = _create_pqc1_stubs()
PQC1_FUNCTIONS = _create_pqc1_functions()
# --------------------
