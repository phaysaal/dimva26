# --------------------
import os
import io
import re
import sys
import copy
import tempfile
import logging
import magic
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, TypedDict, Callable, TextIO
from typing_extensions import NotRequired
from .._intracore.system import command_exec, ExecResult
from .utils import create_tempfile as _create_tempfile
# --------------------
@dataclass
class DisasmResult:
    success: bool
    opcode: str
    partial: bool
    info: str
    method: str

    @classmethod
    def failure(cls, method: str, reason: str = 'failure') -> 'DisasmResult':
        return cls(False, '', True, reason, method)

    @classmethod
    def from_word(cls, word: str, method: str, info: Optional[str]) -> 'DisasmResult':
        if len(word) % 2 != 0:
            word = f'0{word}'
        chunks = [word[i:i+2] for i in range(0, len(word), 2)]
        chunks.reverse()
        return DisasmResult(True, ''.join(chunks), True, info if info else '', method)
# --------------------
@dataclass
class DisasmSourceLocation:
    address: Optional[int] = None
    function: Optional[str] = None
    filename: Optional[str] = None
    line: Optional[int] = None
    backtrace: list['DisasmSourceLocation'] = field(default_factory=list)

    @classmethod
    def from_gdb_log(cls, log: str) -> 'DisasmSourceLocation':
        backtrace = []
        # TODO: Handle case where execution does not reach related address (recover from breakpoint setup)
        for telem in re.finditer(r'\n#([0-9]+)\s+0x([0-9a-f]+)\s+in\s+(\S+)\s+\([^)]*\)(\s+at\s+([^:]+):([0-9]+))?', log):
            backtrace.append(DisasmSourceLocation(int(telem[2], 16), telem[3], telem[5], int(telem[6] if telem[6] is not None else 0)))
        if backtrace:
            backtrace[0].backtrace = backtrace
            return backtrace[0]
        else:
            telem = re.search(r'Breakpoint\s+[0-9]+\s+at\s+0x([0-9a-f]+):\s+file\s+([^,]+),\s+line\s+([0-9]+).', log)
            if telem:
                return DisasmSourceLocation(int(telem[1], 16), None, telem[2], int(telem[3]))
        return DisasmSourceLocation()

    def pprint(self, stream: TextIO, recursive: bool = True) -> None:
        if self.backtrace and recursive:
            _idx = 0
            for telem in self.backtrace:
                stream.write(f'#{_idx}: ')
                telem.pprint(stream, False)
                _idx += 1
        else:
            stream.write(f'@0x{self.address if self.address else 0:x} ({self.function}): {self.filename}:{self.line}\n')
# --------------------
def _guess_binary(source: str, filetype: str) -> str:
    if 'core file' in filetype:
        element = re.search(r"execfn:\s+'([^']+)'", filetype)
        if element:
            return element[1]
        logging.warning('using legacy binary file guesser for core file, might lead to incorrect results')
        strings = command_exec(['strings', source])
        element = re.search(r'\n_=(/[^\n]+)\n', strings.out)
        if element and '.local' not in element[1]:
            return element[1]
        element = re.search(r'\n(/[^\n]+test_harness_crypto_sign)\n', strings.out)
        if element:
            return element[1]
        logging.error('could not trace binary file from core file: %s', source)
    else:
        logging.error('file type %s is not handled', filetype)
    return ''
# --------------------
def _gdb_disasm(filename: str, address: int) -> DisasmResult:
    tscript = _create_tempfile()
    with open(tscript, 'wt') as stream:
        stream.write(f'set pagination off\nset non-stop on\nb main\nr\nx/i 0x{address:x}\nx/x 0x{address:x}\nq')
    cmd = ['gdb', '-x', tscript, filename]
    method = ' '.join(cmd)
    res = command_exec(cmd, timeout=5)
    if res.rv == 0:
        dword = re.search(f'0x{address:x}' + r'(\s*<[^>]*>)?:\s+0x([0-9a-f]+)', res.out)
        info = re.search(f'0x{address:x}' + r'(\s*<[^>]*>)?:\s+([^\n]+)\n', res.out)
        if dword:
            return DisasmResult.from_word(dword[2], method, info[2] if info else None)
    return DisasmResult.failure(method)
# --------------------
def _gdb_get_function(filename: str, address: int) -> Optional[str]:
    tscript = _create_tempfile()
    with open(tscript, 'wt') as stream:
        stream.write(f'set pagination off\nset non-stop on\nb main\nr\ndisassemble /r 0x{address:x}\nq')
    cmd = ['gdb', '-x', tscript, filename]
    method = ' '.join(cmd)
    res = command_exec(cmd, timeout=5)
    if res.rv == 0:
        symbol = re.search(r'Dump of assembler code for function ([^:]+):', res.out)
        if symbol:
            return symbol[1]
    return None
# --------------------
def _gdb_get_source(filename: str, address: int) -> DisasmSourceLocation:
    tscript = _create_tempfile()
    with open(tscript, 'wt') as stream:
        stream.write(f'set pagination off\nset non-stop on\nb main\nr\nb *0x{address:x}\nc\nbacktrace\nq\n')
    cmd = ['gdb', '-x', tscript, filename]
    method = ' '.join(cmd)
    res = command_exec(cmd, timeout=5)
    if res.rv == 0:
        return DisasmSourceLocation.from_gdb_log(res.out)
    return DisasmSourceLocation()
# --------------------
def _lldb_disasm(filename: str, address: int) -> DisasmResult:
    tscript = _create_tempfile()
    with open(tscript, 'wt') as stream:
        stream.write(f'b main\nr\ndisassemble -b -s 0x{address:x}\nq\n')
    cmd = ['lldb', '--source', tscript, filename]
    method = ' '.join(cmd)
    res = command_exec(cmd, timeout=5)
    if res.rv == 0:
        data = re.search(f'0x{address:x}' + r'\s*<[+0-9]*>:\s*(([0-9a-f][0-9a-f]\s)+)\s+([^\n]*)', res.out)
        if data:
            opcode = data[1].strip().replace(' ', '')
            return DisasmResult(True, opcode, False, data[3], method)
    return DisasmResult.failure(method)
# --------------------
def _resolve_filename(filename: str) -> str:
    filetype = magic.from_file(filename)
    if not 'pie executable' in filetype:
        filename = _guess_binary(filename, filetype)
        logging.info('source was not an executable -> autorecovery returned: %s', filename)
    return filename
# --------------------
def disasm(filename: str, address: int) -> DisasmResult:
    _original_filename = filename
    filename = _resolve_filename(filename)
    if filename:
        logging.info('trying autodisasm of %s @%x', filename, address)
        candidate = _lldb_disasm(filename, address)
        if not candidate.success:
            _previous = candidate.method
            candidate = _gdb_disasm(filename, address)
            candidate.method = f'{_previous} then {candidate.method}'
        return candidate
    return DisasmResult.failure(f'no binary found: could not resolve from {_original_filename} -> {filename}')
# --------------------
def function_of(filename: str, address: int) -> Optional[str]:
    filename = _resolve_filename(filename)
    if filename:
        logging.info('trying symbol recovery for address 0x%x in %s', address, filename)
        return _gdb_get_function(filename, address)
    return None
# --------------------
def sourceloc_of(filename: str, address: int) -> DisasmSourceLocation:
    filename = _resolve_filename(filename)
    if filename:
        logging.info('trying source location recovery for address 0x%x in %s', address, filename)
        return _gdb_get_source(filename, address)
    return DisasmSourceLocation()
# --------------------
