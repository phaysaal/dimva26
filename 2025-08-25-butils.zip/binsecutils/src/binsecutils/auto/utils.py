# --------------------
import os
import io
import re
import sys
import copy
import tempfile
import logging
import importlib.resources
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, TypedDict, Callable, TextIO
from typing_extensions import NotRequired
from .._intracore.system import command_exec, ExecResult
from ..binary import BinsecBinaryFile
from . import resources
# --------------------
def create_tempfile() -> str:
    tf = tempfile.NamedTemporaryFile(delete=False)
    tfname = tf.name
    tf.close()
    return tfname
# --------------------
