# --------------------
import os
import re
import sys
import logging
from dataclasses import dataclass, field
from typing import Optional, TypedDict, Callable, TextIO, Any, TypeVar
from typing_extensions import NotRequired, Unpack
import pathlib
# --------------------
@dataclass
class TimecopAlert:
    addr: int
    func: str
    source: str
    loc: int
# --------------------
class TimecopLog:

    def __init__(self, source: str, log: str):
        self.source = source
        self.primitive, self.instance = self.guess_instance(source)
        _summary = re.search(r'ERROR SUMMARY: ([0-9]+) errors from ([0-9]+) contexts', log)
        self.vist = []
        if not _summary:
            logging.warning(f'no error summary in {source}')
            return
        _ctx_cpt = int(_summary[2])
        _data = log[_summary.start():]
        _idx = 0
        for pattern in (r'Conditional jump or move depends on uninitialised value\(s\)[^a]+at 0x([0-9A-F]+):\s([^ ]+)\s\(([^:]+):([0-9]+)\)',
        r'Use of uninitialised value of size[^a]+at 0x([0-9A-F]+):\s([^ ]+)\s\(([^:]+):([0-9]+)\)'):
            for _vuln in re.finditer(pattern, _data):
                addr = int(_vuln[1], 16)
                func = _vuln[2]
                srcf = _vuln[3]
                sloc = int(_vuln[4])
                self.vist.append(TimecopAlert(addr, func, srcf, sloc))

    def guess_instance(self, filename: str) -> tuple[str, str]:
        corename = pathlib.Path(filename).stem
        corename = corename.replace('output', '').replace('crypto_sign', '').replace('__', '_')
        if corename.endswith('_'):
            corename = corename[:-1]
        splits = corename.split('_')
        if splits[0].startswith('ryde'):
            splits = ['ryde'] + splits
        return splits[0], '_'.join(splits[1:])

    def pprint_srcvenn(self):
        iset = set()
        for alert in self.vist:
            iset.add(f'{alert.source}:{alert.loc}')
        for elem in iset:
            sys.stdout.write(f'{self.primitive}; {self.instance}; {elem}\n')
# --------------------
# --------------------
