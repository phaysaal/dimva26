# --------------------
import os
import io
import re
import sys
import copy
import tempfile
import logging
import concurrent.futures
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, TypedDict, Callable, TextIO, Any, TypeVar
from typing_extensions import NotRequired, Unpack
from .binary import BBFOpcode, BinsecBinaryFile, BinsecBinaryLocation
from ._intracore.system import command_exec, ExecResult
from .auto import pqc1, autodisasm
# --------------------
T = TypeVar("T")
# --------------------
class BinsecOpcodesResult(TypedDict):
    opcodes: dict[str, BinsecBinaryLocation]
    mnemonics: list[str]
    counters: dict[str, int]
# --------------------
class BinsecRunOptions(TypedDict, total=False):
    timeout: Optional[int]
    remove_ct: bool
    remove_ct_secret: bool
    ct_secret_byte: int
    max_depth: int
    growth_factor: int
    solver_timeout: int
    timeout_cap: int
    replace_opcodes: set[str]
    replace_functions: set[str]
# --------------------
class _RunBreak(Exception):
    pass
# --------------------
@dataclass
class BinsecScriptPatch:
    remove_ct_secret: bool = False
    remove_ct_public: bool = False
    ct_secret_byte: int = -1
    bypass_opcodes: set[str] = field(default_factory=set)
    known_stubs: dict[str, str] = field(default_factory=dict)
    replace_functions: set[str] = field(default_factory=set)
    known_functions: dict[str, str] = field(default_factory=dict)

    def __call__(self, target: TextIO, source: TextIO) -> None:
        replaced = set()
        for line in source:
            _symbol = self._is_function_replace(line)
            if _symbol:
                replaced.add(_symbol)
            if self.remove_ct_secret and self._is_ct_secret(line):
                continue
            if self.remove_ct_public and self._is_ct_public(line):
                continue
            if self.ct_secret_byte >= 0 and self._is_ct_secret_mode_1(line):
                for secret in self._get_ct_secrets(line):
                    target.write(f'{secret}_byte<8> := 0x00\n')
                    target.write(f'{secret}_byte := secret\n')
                    target.write(f'@[<{secret}>+{self.ct_secret_byte}, 1] := {secret}_byte\n')
                continue
            if self.ct_secret_byte >= 0 and self._is_ct_secret_mode_2(line):
                target.write(f'if i = {self.ct_secret_byte} then {line.strip()}; end\n')
                continue
            if self._is_final_script(line):
                for opcode in self.bypass_opcodes:
                    target.write(self.known_stubs.get(opcode, f'replace opcode {opcode} by\nend\n'))
                for fname in self.replace_functions:
                    if fname not in replaced:
                        if fname not in self.known_functions:
                            logging.warning('no known stub for function %s -> building one', fname)
                        target.write(self.known_functions.get(fname, f'replace <{fname}>(_) by\n return 0\nend\n'))
            target.write(line)

    def bypass_known_prefix(self, prefix: str) -> int:
        clen = len(self.bypass_opcodes)
        for known in self.known_stubs.keys():
            if known.startswith(prefix):
                self.bypass_opcodes.add(known)
        return len(self.bypass_opcodes) - clen

    def _samples(self, line: str) -> list[str]:
        return [e for e in line.split() if e]

    def _is_final_script(self, line: str) -> bool:
        samples = self._samples(line)
        return len(samples) > 1 and samples[0] in ('reach', 'explore')

    def _is_ct_secret_mode_1(self, line: str) -> bool:
        samples = self._samples(line)
        return len(samples) > 2 and samples[1] == 'global' and samples[0] == 'secret'

    def _is_ct_secret_mode_2(self, line: str) -> bool:
        samples = self._samples(line)
        return len(samples) > 1 and samples[-1] == 'secret'

    def _is_ct_secret(self, line: str) -> bool:
        return self._is_ct_secret_mode_1(line) or self._is_ct_secret_mode_2(line)

    def _get_ct_secrets(self, line: str) -> list[str]:
        samples = self._samples(line)[2:]
        samples = [s.replace(',', '').strip() for s in samples if s.strip() != ',']
        return samples

    def _is_ct_public(self, line: str) -> bool:
        # TODO: Similar to is_ct_secret: split modes
        samples = self._samples(line)
        return len(samples) > 2 and samples[1] == 'global' and samples[0] == 'public'

    def _is_function_replace(self, line: str) -> Optional[str]:
        match = re.match(r'replace <([^>]*)>', line.strip())
        if match:
            return match[1]
# --------------------
@dataclass
class BinsecScript:
    source: str
    duplicates: list[str] = field(default_factory=list)
    delete_duplicates: bool = False

    def __del__(self) -> None:
        for filename in self.duplicates:
            if self.delete_duplicates:
                os.remove(filename)

    def make_duplicate(self, patch: Callable[[TextIO, TextIO], None] = lambda t, s: None if t.write(s.read()) else None) -> str:
        duplicate = tempfile.NamedTemporaryFile(prefix='binsec.tmp.', mode='w+t', delete=False)
        self.duplicates.append(duplicate.name)
        duplicate.close()
        with open(self.source) as stream:
            with open(duplicate.name, 'wt') as target:
                patch(target, stream)
        return duplicate.name
# --------------------
class BinsecLogReason(Enum):
    Complete = 0x00
    Unknown = 0x01
    Syscall = 0x02
    Uninterpreted = 0x03
    MaxDepth = 0x04
    Timeout = 0x05
    SolverTimeout = 0x06
    CTLeak = 0x07
    NoInstructionStop = 0x08
    NoOutput = 0x09
    ExceptionRaised = 0x0a
# --------------------
class BinsecStatistics:
    PARSE_PREPROCESSING_STATS = r'Preprocessing simplifications\s+' + r'\s+'.join(
        [idt + r'\s+([0-9]+)' for idt in ('total', 'true', 'false', 'constant enum')])
    PARSE_SATQUERIES_STATS = r'Satisfiability queries\s+' + r'\s+'.join(
        [idt + r'\s+([0-9]+(.[0-9]+)?)' for idt in ('total', 'sat', 'unsat', 'unknown', 'time', 'average')])
    PARSE_EXPLORATION_STATS = r'Exploration\s+' + r'\s+'.join([idt + r'\s+([0-9]+)' for idt in (
        'total paths', 'completed/cut paths', 'pending paths', 'stale paths', 'failed assertions', 'branching points',
        'max path depth', r'visited instructions \(unrolled\)', r'visited instructions \(static\)')])
    PARSE_CHECKCT_STATS = r'\[checkct:result\] Program status is : (unknown|secure|unsecure|insecure) \(([0-9]+.[0-9]+)\)'

    def __init__(self, log: str):
        stats_p, stats_s, stats_e, stats_c = (re.search(r, log) for r in (self.PARSE_PREPROCESSING_STATS, self.PARSE_SATQUERIES_STATS, self.PARSE_EXPLORATION_STATS, self.PARSE_CHECKCT_STATS))
        self.simplification_total = int(stats_p[1]) if stats_p and stats_p[1] else None
        self.simplification_true = int(stats_p[2]) if stats_p and stats_p[2] else None
        self.simplification_false = int(stats_p[3]) if stats_p and stats_p[3] else None
        self.simplification_constant_enum = int(stats_p[4]) if stats_p and stats_p[4] else None
        self.sat_total = int(stats_s[1]) if stats_s and stats_s[1] else None
        self.sat_sat = int(stats_s[3]) if stats_s and stats_s[3] else None
        self.sat_unsat = int(stats_s[5]) if stats_s and stats_s[5] else None
        self.sat_unknown = int(stats_s[7]) if stats_s and stats_s[7] else None
        self.sat_time = float(stats_s[9]) if stats_s and stats_s[9] else None
        self.sat_average_time = float(stats_s[11]) if stats_s and stats_s[11] else None
        self.total_paths = int(stats_e[1]) if stats_e and stats_e[1] else None
        self.completed_paths = int(stats_e[2]) if stats_e and stats_e[2] else None
        self.pending_paths = int(stats_e[3]) if stats_e and stats_e[3] else None
        self.stale_paths = int(stats_e[4]) if stats_e and stats_e[4] else None
        self.failed_assertions = int(stats_e[5]) if stats_e and stats_e[5] else None
        self.branching_points = int(stats_e[6]) if stats_e and stats_e[6] else None
        self.max_path_depth = int(stats_e[7]) if stats_e and stats_e[7] else None
        self.visited_unrolled = int(stats_e[8]) if stats_e and stats_e[8] else None
        self.visited_static = int(stats_e[9]) if stats_e and stats_e[9] else None
        self.checkct_status = stats_c[1] if stats_c else None
        self.checkct_time = float(stats_c[2]) if stats_c and stats_c[2] else None

    def __str__(self) -> str:
        return f'# {self.sat_total}q ({self.sat_average_time}s/{self.sat_time}s), {self.completed_paths}/{self.total_paths} paths, {self.max_path_depth} max depth'
# --------------------
class BinsecLog:

    PARSE_SYSCALL = r'\[sse:error\] Cut path ([0-9]+) \(uninterpreted "syscall"\) @ 0x([0-9a-f]+)'
    PARSE_UNINTERPRETED = r'\[sse:error\] Cut path ([0-9]+) \(uninterpreted ("[^"]+")\) @ 0x([0-9a-f]+)'
    PARSE_MAXDEPTH = r'\[sse:warning\] Cut path ([0-9]+) \(max depth\) @ 0x([0-9a-f]+)'
    PARSE_TIMEOUT = r'- timeout has left \(at least\) ([0-9]+) pending paths'
    PARSE_SOLVERTIMEOUT = r'- ([0-9]+) SMT solver queries remain unsolved \(-fml-solver-timeout\)'
    PARSE_NOINSTSTOP = r'\[disasm:warning\] No instruction at 0x([0-9a-f]+) ... stopping'
    PARSE_EXCEPTION = r'Fatal error: exception ([^\n]+)'

    PARSE_CTLEAK = r'\[checkct:result\] Instruction 0x([0-9a-f]+) has (control flow|memory access|multiplication|dividend|divisor) leak'
    PARSE_DEBUGEXEC = r'\[sse:debug\] 0x([0-9a-f]+) ([^\n^#]*)\n'

    PARSE_FORWARDED_EXCEPTION = r'\[utils:exception\]: ([^\n]*)'
    PARSE_FORWARDED_STATUS = r'\[utils:status\]: ([^\n]*)'
    PARSE_FORWARDED_REASON = r'\[utils:reason\]: ([^\n]*)'
    PARSE_FORWARDED_COMMAND = r'\[utils:command\]: ([^\n]*)'
    PARSE_FORWARDED_SOURCE = r'\[utils:source\]: ([^\n]*)'

    def __init__(self, res: ExecResult, strict: bool = True, leak_only: bool = True, source: Optional[list[str]] = None, forwarded: bool = False):
        self._res = res
        self.origin = None
        self.source = source
        self.complete = (
                res.rv == 0
                and 'Exploration is incomplete' not in res.out
                and '[sse:error]' not in res.out
                and (not strict or 'Threat to completeness' not in res.out)
        )
        self.reason = BinsecLogReason.Complete if self.complete else BinsecLogReason.Unknown
        self.data = None
        self.detail = None
        self.resolution: Optional[str] = None
        try:
            self.statistics = BinsecStatistics(res.out)
        except ValueError:
            self.statistics = BinsecStatistics('')
        self.last = None
        for debugi in re.finditer(self.PARSE_DEBUGEXEC, res.out):
            self.last = (debugi[1], debugi[2].strip())
        self.patch_info: Optional[BinsecScriptPatch] = None
        self.report: dict[int, autodisasm.DisasmSourceLocation] = {}
        usysc = re.search(self.PARSE_SYSCALL, res.out)
        unint = re.search(self.PARSE_UNINTERPRETED, res.out)
        noistop = re.search(self.PARSE_NOINSTSTOP, res.out)
        mdepth = re.search(self.PARSE_MAXDEPTH, res.out)
        toraised = re.search(self.PARSE_TIMEOUT, res.out)
        storaised = re.search(self.PARSE_SOLVERTIMEOUT, res.out)
        rexcept = re.search(self.PARSE_EXCEPTION, res.out)
        ctleak = re.search(self.PARSE_CTLEAK, res.out)
        if ctleak:
            self.reason = BinsecLogReason.CTLeak
            self.data = f'{ctleak[2]}:{ctleak[1]}'
            self.detail = ''
            for ctv in re.finditer(self.PARSE_CTLEAK, res.out):
                self.detail += f', {ctv[2]}:{ctv[1]}' if self.detail else f'{ctv[2]}:{ctv[1]}'
            if leak_only:
                self.complete = True
        elif usysc:
            self.reason = BinsecLogReason.Syscall
            self.data = usysc[2]
        elif unint:
            self.reason = BinsecLogReason.Uninterpreted
            self.detail = unint[2]
            self.data = unint[3]
        #elif noistop:
        #    self.reason = BinsecLogReason.NoInstructionStop
        #    self.data = noistop[1]
        elif mdepth:
            self.reason = BinsecLogReason.MaxDepth
            self.data = mdepth[2]
        elif res.to or toraised:
            self.reason = BinsecLogReason.Timeout
            self.detail = str(res.to)
        elif storaised:
            self.reason = BinsecLogReason.SolverTimeout
        elif rexcept:
            self.reason = BinsecLogReason.ExceptionRaised
            self.data = rexcept[1]
        elif res.rv != 0 and not res.out.strip():
            self.reason = BinsecLogReason.NoOutput
            self.detail = 'possible memory exhaust?'
        if forwarded:
            self._recover_forwarded_data()
        if self.reason == BinsecLogReason.CTLeak:
            binary_file = self._recover_binary_filename(self.source)
            if binary_file is None and self.origin is not None:
                binary_file = self.origin
            if binary_file:
                for ctv in re.finditer(self.PARSE_CTLEAK, res.out):
                    #if 'multiplication' in ctv[0]:
                    #    continue
                    addr = int(ctv[1], 16)
                    try:
                        self.report[addr] = autodisasm.sourceloc_of(binary_file, addr)
                    except FileNotFoundError:
                        self.report[addr] = autodisasm.sourceloc_of(self.origin, addr) if self.origin is not None else 'NotFound'

    def _recover_binary_filename(self, source: Optional[list[str]]) -> Optional[str]:
        if source:
            target = BinsecTarget(caller=source)
            return target.binary_filename()
        return None

    def _recover_forwarded_data(self):
        fwd_exception = re.search(self.PARSE_FORWARDED_EXCEPTION, self._res.out)
        fwd_status = re.search(self.PARSE_FORWARDED_STATUS, self._res.out)
        fwd_reason = re.search(self.PARSE_FORWARDED_REASON, self._res.out)
        fwd_command = re.search(self.PARSE_FORWARDED_COMMAND, self._res.out)
        fwd_source = re.search(self.PARSE_FORWARDED_SOURCE, self._res.out)
        if fwd_status:
            status = fwd_status[1]
            if status == 'complete':
                self.complete = True
            elif status == 'incomplete':
                self.complete = False
        if fwd_reason:
            reason = fwd_reason[1]
            try:
                self.reason = BinsecLogReason[reason]
            except KeyError:
                pass
        if fwd_exception:
            e = fwd_exception[1]
            self.reason = BinsecLogReason.ExceptionRaised
            self.data = e
        if fwd_command:
            self.source = [e.strip() for e in fwd_command[1].split() if e.strip()]
        if fwd_source:
            self.origin = fwd_source[1]

    @property
    def output(self) -> str:
        return self._res.out

    def __str__(self) -> str:
        return f'{self.reason.name} ({self.data}, {self.detail}, {self.resolution}) {self.statistics} [last={self.last}]'

    def small_str(self) -> str:
        _kostring = '"KO"'
        return f'{self.reason.name} ({self.detail if self.detail and self.detail != _kostring else self.resolution if self.resolution else self.data})'

    def pqc1_str(self) -> str:
        return f'| {self.detail if self.statistics.checkct_status == "insecure" else self.statistics.checkct_status} | {self.statistics.total_paths} | {self.statistics.max_path_depth} | {self.statistics.visited_static} | {self.statistics.checkct_time} |'

    def paper1_str(self) -> str:
        return f'{self._guess_paper1_primitive()}, {self._guess_paper1_instance()}, {self._paper1_result()}'

    def _guess_paper1_primitive(self):
        splits = self.origin.split('/') if self.origin else []
        return splits[2] if len(splits) > 2 else '?'

    def _guess_paper1_instance(self):
        splits = self.origin.split('/') if self.origin else []
        primitive = self._guess_paper1_primitive()
        if primitive in ('cross', 'less', 'sqisign'):
            return splits[5].replace('taint_crypto_sign_', '') if len(splits) > 5 else '?'
        idx = 5 if primitive in ('mayo',) else 6 if primitive in ('uov',) else 4
        return splits[idx] if len(splits) > idx else '?'

    def _paper1_result(self):
        if self.statistics.checkct_status == 'insecure':
            return str(len(self.detail.split(',')))
        if self.statistics.checkct_status == 'secure':
            return '0'
        return 'TIMEOUT' if self.reason.name == 'Timeout' else 'CRASH'
# --------------------
@dataclass
class BinsecTarget:
    caller: list[str] = field(default_factory=lambda: ['binsec'])
    script: Optional[BinsecScript] = None

    def patched_run(self, args: list[str], patch: BinsecScriptPatch, **kwargs: Unpack[BinsecRunOptions]) -> BinsecLog:
        cmd = copy.copy(self.caller)
        cmd.extend(args)
        self._patch_script_file(cmd, patch)
        self._patch_command(cmd, **kwargs)
        logging.info('%s', ' '.join(cmd))
        return BinsecLog(command_exec(cmd, timeout=kwargs.get('timeout')), source=cmd)

    def _patch_command(self, cmd: list[str], **kwargs: Unpack[BinsecRunOptions]) -> None:
        if kwargs.get('max_depth'):
            _val = str(kwargs.get('max_depth'))
            try:
                cmd[self._max_depth_index()] = _val
            except IndexError:
                cmd.extend(['-sse-depth', _val])
        if kwargs.get('timeout'):
            _tval = kwargs.get('timeout')
            _val = str(int(0.9 * (_tval if _tval else 0)))
            try:
                cmd[self._command_argument_index('-sse-timeout')] = _val
            except IndexError:
                cmd.extend(['-sse-timeout', _val])
        if kwargs.get('solver_timeout'):
            _val = str(kwargs.get('solver_timeout'))
            try:
                cmd[self._command_argument_index('-fml-solver-timeout')] = _val
            except IndexError:
                cmd.extend(['-fml-solver-timeout', _val])
        if kwargs.get('remove_ct', False) and kwargs.get('remove_ct_secret', False):
            _trm = set()
            for arg in cmd:
                if arg.strip().startswith('-checkct'):
                    _trm.add(arg)
            for arg in _trm:
                cmd.remove(arg)

    def create_binsec_call(self, args: list[str]) -> list[str]:
        cmd = copy.copy(self.caller)
        cmd.extend(args)
        return cmd

    def handles_opcode(self, opcode: BBFOpcode) -> bool:
        cmd = self.create_binsec_call(['-isa', 'amd64', '-disasm-decode', str(opcode)])
        res = command_exec(cmd)
        return res.rv == 0 and 'unsupported' not in res.out and 'undecoded' not in res.out

    def unhandled_opcodes(self, binaries: list[BinsecBinaryFile], text_only: bool = True, parallel: int = 20) -> BinsecOpcodesResult:
        failed: dict[str, BinsecBinaryLocation] = {}
        pending = set()
        mnemos = set()
        count = 0
        rcount = [0]
        for binary in binaries:
            pending |= (binary.text_opcodes if text_only else binary.opcodes)

        def wrapper(opcode: BBFOpcode, rcount: list[int]) -> tuple[bool, BBFOpcode]:
            rcval = int(100 * (rcount[0] / len(pending)))
            sys.stdout.write(f'> [{rcval}%] checking {opcode.source.opcode}\r')
            r = self.handles_opcode(opcode)
            return r, opcode

        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as executor:
            futures = [executor.submit(wrapper, opcode, rcount) for opcode in pending]
            for future in concurrent.futures.as_completed(futures):
                res, opcode = future.result()
                rcount[0] += 1
                if not res:
                    count += 1
                    mnemos.add(opcode.source.mnemo)
                    failed[opcode.source.opcode] = {
                        'binary': opcode.source.binary,
                        'loc': opcode.source.loc,
                        'mnemo': opcode.source.mnemo
                    }
                    logging.warning('unhandled opcode %s (@%s - %s)', opcode.source.opcode, opcode.source.loc,
                                    opcode.source.mnemo)
        result: BinsecOpcodesResult = {
            'opcodes': failed,
            'mnemonics': list(mnemos),
            'counters': {'opcode': count, 'mnemonics': len(mnemos)}
        }
        return result

    def _feedback_run_handle_syscall(self, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        addr = int(str(log.data), 16)
        source = autodisasm.function_of(target.path, addr)
        logging.warning('uninterpreted address: %s (%s)', log.data, source)
        patch.bypass_opcodes.add('0f 05')
        logging.info('bypassing opcode: 0f 05')

    def _feedback_run_handle_uninterpreted(self, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        addr = int(str(log.data), 16)
        logging.warning('uninterpreted address: %s (%i) [%s]', log.data, addr, log.detail)
        try:
            opcode = target.opcode(addr)
            patch.bypass_opcodes.add(opcode.source.opcode)
            logging.info('patching opcode: %s', opcode.source.opcode)
        except KeyError as e:
            logging.warning('location %s is out of dumped, trying automatic detection', log.data)
            autod = autodisasm.disasm(target.path, addr)
            if autod.success:
                logging.info('managed to recover opcode: %s', autod.opcode)
                logging.info('successful opcode recovery method: %s', autod.method)
                if not autod.partial:
                    patch.bypass_opcodes.add(autod.opcode)
                elif patch.bypass_known_prefix(autod.opcode) == 0:
                    logging.error('no known opcode for recovered prefix at address %s', log.data)
                    logging.error(f'auto disassembly: {autod.method}')
                    log.resolution = f'no known prefix ({autod.info})'
                    raise _RunBreak
            else:
                logging.error('could not recover failed opcode at address %s', log.data)
                logging.error(f'auto disassembly: {autod.method}')
                log.resolution = f'cannot disassemble ({autod.info})'
                raise _RunBreak

    def _feedback_run_handle_noinstructionstop(self, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        self._feedback_run_handle_uninterpreted(log, patch, target, opts, growth)

    def _feedback_run_autogrowth(self, lopt: str, copt: str, default: int, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        try:
            oval = opts[lopt] if lopt in opts and opts[lopt] else self.command_argument(copt, int)
        except IndexError:
            logging.warning('ex nihilo %s/%s appearance', lopt, copt)
            oval = default
        if lopt == 'timeout' and growth * oval > opts['timeout_cap']:
            raise _RunBreak
        opts[lopt] = growth * oval
        logging.info('extending %s/%s %i -> %i', lopt, copt, oval, growth * oval)

    def _feedback_run_handle_maxdepth(self, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        self._feedback_run_autogrowth('max_depth', '-sse-depth', 1000, log, patch, target, opts, growth)

    def _feedback_run_handle_timeout(self, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        self._feedback_run_autogrowth('timeout', '-sse-timeout', 60, log, patch, target, opts, growth)

    def _feedback_run_handle_solvertimeout(self, log: BinsecLog, patch: BinsecScriptPatch, target: BinsecBinaryFile, opts: BinsecRunOptions, growth: int) -> None:
        self._feedback_run_autogrowth('solver_timeout', '-fml-solver-timeout', 60, log, patch, target, opts, growth)

    def feedback_run(self, **kwargs: Unpack[BinsecRunOptions]) -> BinsecLog:
        patch = BinsecScriptPatch(
            remove_ct_secret=kwargs.get('remove_ct_secret', True),
            remove_ct_public=kwargs.get('remove_ct', True),
            ct_secret_byte=kwargs.get('ct_secret_byte', -1),
            known_stubs=pqc1.PQC1_STUBS,
            bypass_opcodes=kwargs.get('replace_opcodes', set()),
            known_functions=pqc1.PQC1_FUNCTIONS,
            replace_functions=kwargs.get('replace_functions', set())
        )
        additional_args = ['-sse-missing-symbol', 'quiet']
        target = self.binary_file()
        opts = copy.copy(kwargs)
        log = self.patched_run(additional_args, patch, **opts)
        growth = kwargs.get('growth_factor', 10)
        while not log.complete:
            logging.warning('incomplete feedback-run. cause: %s', log.reason)
            logging.debug(log._res.out)
            handler = f'_feedback_run_handle_{log.reason.name.lower()}'
            if hasattr(self, handler):
                try:
                    getattr(self, handler)(log, patch, target, opts, growth)
                except _RunBreak:
                    break
            else:
                logging.error('no rule to handle %s feedback: \n%s', log.reason, log._res.out)
                break
            log = self.patched_run(additional_args, patch, **opts)
        if log.complete:
            logging.info('feedback run has succeeded on %s: \n%s', log.reason, log._res.out)
        else:
            logging.error('feedback run did not complete: %s', log.reason)
        log.patch_info = patch
        return log

    def auto_pqc1(self, **kwargs: Unpack[BinsecRunOptions]) -> BinsecLog:
        bf = self.binary_filename()
        snapshot = pqc1.pqc1_coredump(bf)
        self.caller[self._binary_file_index()] = snapshot
        return self.feedback_run(**kwargs)

    def auto_pqc2(self, **kwargs: Unpack[BinsecRunOptions]) -> BinsecLog:
        bf = self.binary_filename()
        snapshot = pqc1.pqc2_coredump(bf)
        scriptfn = pqc1.pqc2_script()
        self.caller[self._binary_file_index()] = snapshot
        self.caller[self._script_file_index()] = scriptfn
        return self.feedback_run(**kwargs)

    def _command_argument_index(self, opt: str) -> int:
        for _i in range(len(self.caller)):
            if self.caller[_i] == opt:
                if _i + 1 >= len(self.caller):
                    raise KeyError(f'malformed binsec caller: no argument after {opt}')
                return _i + 1
        raise IndexError(f'no {opt} option in caller')

    def command_argument(self, opt: str, type: Callable[[Any], T]) -> T:
        return type(self.caller[self._command_argument_index(opt)])

    def _script_file_index(self) -> int:
        return self._command_argument_index('-sse-script')

    def script_filename(self) -> str:
        return self.caller[self._script_file_index()]

    def script_file(self) -> BinsecScript:
        return BinsecScript(self.script_filename())

    def _patch_script_file(self, cmd: list[str], patch: Callable[[TextIO, TextIO], None]) -> None:
        if self.script is None:
            self.script = self.script_file()
        cmd[self._script_file_index()] = self.script.make_duplicate(patch)

    def _binary_file_index(self) -> int:
        _constrained = False
        for _i in range(len(self.caller)):
            if self.caller[_i].startswith('-'):
                _constrained = True
            else:
                if not _constrained and self.caller[_i] != 'binsec':
                    return _i
                _constrained = False
        raise IndexError(f'no binary in binsec caller')

    def _max_depth_index(self) -> int:
        return self._command_argument_index('-sse-depth')

    def max_depth(self) -> int:
        return int(self.caller[self._max_depth_index()])

    def binary_filename(self) -> str:
        return self.caller[self._binary_file_index()]

    def binary_file(self) -> BinsecBinaryFile:
        return BinsecBinaryFile(self.binary_filename())
# --------------------
# --------------------
