# --------------------
import os
import sys
import logging
import concurrent.futures
import pathlib
from colorama import Fore, Back, Style
from enum import Enum
from tqdm import tqdm
from typing import Union
import matplotlib_venn
# --------------------
import yaml
try:
    from yaml import CLoader as YamlLoader, CDumper as YamlDumper
except ImportError:
    from yaml import Loader as YamlLoader, Dumper as YamlDumper  # type: ignore
# --------------------
from argparse import ArgumentParser
# --------------------
from ._intracore.logging import ColoredIntraFormatter
from ._intracore.system import ExecResult
# --------------------
from .binary import BinsecBinaryFile, OBJDUMP_PARSERS
from .binsec import BinsecTarget, BinsecLog, BinsecLogReason
from .timecop import TimecopLog
# --------------------
def _logger_init(args) -> None:
    logging_handler = logging.StreamHandler()
    logging_handler.setFormatter(ColoredIntraFormatter())
    logging.basicConfig(
        format='%(message)s',
        handlers=(logging_handler,),
        level=logging.DEBUG if args.debug else logging.INFO,
        force=True
    )
# --------------------
def _exec_command_extract_opcodes(args) -> None:
    count = 0
    pending = set()
    for binary in args.binary:
        bbf = BinsecBinaryFile(binary)
        pending |= (bbf.text_opcodes if args.text_only else bbf.opcodes)
    for opcode in pending:
        logging.info('found opcode %s', opcode)
        count += 1
    logging.info('found %i opcodes', count)
# --------------------
def _exec_command_check_opcodes(args) -> None:
    binsec = BinsecTarget()
    result = binsec.unhandled_opcodes([BinsecBinaryFile(b) for b in args.binary], args.text_only, args.workers)
    if result['counters']['opcode']:
        logging.error('%i unhandled opcodes (%i distinct mnemonics)', result['counters']['opcode'], result['counters']['mnemonics'])
    if result['mnemonics']:
        for mnemo in result['mnemonics']:
            logging.warning('mnemonic of unhandled opcodes: %s', mnemo)
    with open(args.report, 'wt') as stream:
        yaml.dump(result, stream)
    logging.info('wrote report in %s', args.report)
    if args.patch is not None:
        with open(args.patch, 'wt') as stream:
            for opcode in result['opcodes'].keys():
                stream.write(f'replace opcode {opcode.replace(" ", "")} by\nend\n')
        logging.info('wrote patch in %s', args.patch)
# --------------------
def _binsec_targets_iter(args):
    if args.run is not None:
        yield BinsecTarget(caller=args.run.split())  # TODO: correctly parse
    elif args.run_file is not None:
        with open(args.run_file) as stream:
            for line in stream:
                yield BinsecTarget(caller=line.strip().split())  # TODO: correctly parse
# --------------------
class FeedbackSummaryFormat(Enum):
    Default = 0x00
    PQC1 = 0x01
    Paper1 = 0x02
    Srcvenn = 0x03
# --------------------
def _print_srcvenn_results(results: dict[str, BinsecLog]) -> None:
    sys.stdout.write('-- begin srcvenn\n')
    for _, log in results.items():
        primitive, instance = log._guess_paper1_primitive(), log._guess_paper1_instance()
        try:
            if log.report.items():
                iset = set()
                for vulnsrc in log.report.values():
                    iset.add(f'{vulnsrc.filename}:{vulnsrc.line}')
                for elem in iset:
                    sys.stdout.write(f'{primitive}; {instance}; {elem}\n')
        except AttributeError:
            pass
    sys.stdout.write('-- end srcvenn\n')
# --------------------
def _print_feedback_summary_results(results: dict[str, BinsecLog], full: bool = False, fmt: FeedbackSummaryFormat = FeedbackSummaryFormat.Default) -> None:
    logging.info('-' * 80)
    logging.info('summary of results')
    logging.info('-' * 80)
    if fmt == FeedbackSummaryFormat.Srcvenn:
        _print_srcvenn_results(results)
        return
    for name, log in results.items():
        sys.stdout.write(f'[result] : {name} : ')
        _backcolor = Back.GREEN if isinstance(log, BinsecLog) and log.complete else Back.YELLOW if isinstance(log, BinsecLog) and log.reason == BinsecLogReason.Timeout else Back.RED
        if fmt == FeedbackSummaryFormat.PQC1:
            _reportstr = log.pqc1_str() if isinstance(log, BinsecLog) else log
        elif fmt == FeedbackSummaryFormat.Paper1:
            _reportstr = log.paper1_str() if isinstance(log, BinsecLog) else log
        else:
            _reportstr = (str(log) if full else log.small_str()) if isinstance(log, BinsecLog) else log
        sys.stdout.write(f'{_reportstr}')
        sys.stdout.write(f'\n')
    logging.info('-' * 80)
    for name, log in results.items():
        if fmt == FeedbackSummaryFormat.Paper1:
            if isinstance(log, BinsecLog):
                sys.stdout.write(f'[result] : sources for {log._guess_paper1_primitive()}, {log._guess_paper1_instance()}: ')
            else:
                sys.stdout.write(f'[result] : sources for {name}: ')
            try:
                if log.report.items():
                    iset = set()
                    for vulnsrc in log.report.values():
                        iset.add(f'{vulnsrc.filename}:{vulnsrc.line}')
                    sys.stdout.write(', '.join(iset))
            except AttributeError:
                pass
            sys.stdout.write('\n')
        else:
            sys.stdout.write(f'{Style.BRIGHT}[result] : executed backtrace for {name} : {Style.RESET_ALL}\n')
            try:
                if log.report.items():
                    for vuln, vulnsrc in log.report.items():
                        sys.stdout.write(f'[]       : leak @0x{vuln:x}\n')
                        vulnsrc.pprint(sys.stdout)
            except AttributeError:
                sys.stdout.write(f'[]       : not applicable (example was not executed)\n')
    logging.info('-' * 80)
# --------------------
def _exec_command_feedback_run(args) -> None:
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(
                target.feedback_run,
                timeout=args.run_timeout if args.run_timeout > 0 else None,
                timeout_cap=args.run_timeout_cap,
                growth_factor=args.growth_factor,
                replace_opcodes=set(args.replace_opcode))
            : target
            for target in _binsec_targets_iter(args)
        }
        results = {}
        for future in concurrent.futures.as_completed(futures.keys()):
            try:
                res = future.result()
            except Exception as e:
                res = e
            results[' '.join(futures[future].caller)] = res
        _print_feedback_summary_results(results, args.full_report)
# --------------------
def _exec_command_auto_pqc(args, mode: int) -> None:
    if not os.path.isdir(args.output_dir):
        os.makedirs(args.output_dir, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(
                target.auto_pqc1 if mode == 1 else target.auto_pqc2,
                timeout=args.run_timeout if args.run_timeout > 0 else None,
                timeout_cap=args.run_timeout_cap,
                remove_ct=args.remove_ct,
                remove_ct_secret=args.remove_ct_secret and args.remove_ct,
                ct_secret_byte=args.ct_secret_byte,
                growth_factor=args.growth_factor,
                replace_opcodes=set(args.replace_opcode),
                replace_functions=set(args.replace_function))
            : target.binary_filename()
            for target in _binsec_targets_iter(args)
        }
        results: dict[str, BinsecLog] = {}
        fid = 0
        for future in concurrent.futures.as_completed(futures):
            try:
                res: Union[BinsecLog, Exception] = future.result()
            except Exception as e:
                res = e
            key = futures[future]
            while key in results:
                key += '?'
            results[key] = res
            while os.path.isfile(os.path.join(args.output_dir, f'{fid}.log')):
                fid += 1
            resfile = os.path.join(args.output_dir, f'{fid}.log')
            logging.info('logging item results to %s', resfile)
            with open(resfile, 'wt') as stream:
                stream.write(f'[utils:source]: {key}\n')
                if isinstance(res, Exception):
                    stream.write(f'[utils:exception]: {res}\n')
                    stream.write(f'[utils:status]: incomplete\n')
                else:
                    stream.write(f'[utils:command]: {" ".join(res.source)}\n')
                    stream.write(f'[utils:opcodes]: {", ".join(res.patch_info.bypass_opcodes)}\n')
                    stream.write(f'[utils:status]: {"complete" if res.complete else "incomplete"}\n')
                    stream.write(f'[utils:reason]: {res.reason.name}\n')
                    stream.write(res.output)
        _print_feedback_summary_results(results, args.full_report)
# --------------------
def _exec_command_auto_pqc1(args) -> None:
    _exec_command_auto_pqc(args, 1)
# --------------------
def _exec_command_auto_pqc2(args) -> None:
    _exec_command_auto_pqc(args, 2)
# --------------------
def _exec_command_analyze_log(args) -> None:
    results = {}
    for logfile in args.log:
        with open(logfile, 'rt') as stream:
            results[logfile] = BinsecLog(ExecResult(0, False, stream.read(), ''), forwarded=True)
    _print_feedback_summary_results(results, args.full_report, getattr(FeedbackSummaryFormat, args.format.capitalize()))
# --------------------
def _exec_command_make_venn(args) -> None:
    class SrcTuple:

        HASH_LIST = {}
        HASHED = []
        HASHMAX = 0

        def __init__(self, src: str):
            splits = src.split(';')
            try:
                self.primitive = splits[0].strip()
                self.instance = splits[1].strip()
                self.loc = splits[2].strip()
            except IndexError:
                raise ValueError(f'incorrectly formatted venn src line (must be "primitive; instance; location"): {src.strip()}')

        def __eq__(self, other):
            if not isinstance(other, SrcTuple):
                return NotImplemented
            return self.primitive == other.primitive and self.instance == other.instance and (
                    self.loc == other.loc or
                    self.loc.endswith(other.loc) or
                    other.loc.endswith(self.loc))

        def __hash__(self):
            if id(self) in SrcTuple.HASH_LIST:
                return SrcTuple.HASH_LIST[id(self)]
            for e in SrcTuple.HASHED:
                if self == e:
                    return SrcTuple.HASH_LIST[id(e)]
            SrcTuple.HASHMAX += 1
            SrcTuple.HASH_LIST[id(self)] = SrcTuple.HASHMAX
            SrcTuple.HASHED.append(self)
            return SrcTuple.HASHMAX

    target = args.output
    data: dict[str, set] = {}
    for logfile in args.vennlog:
        key = pathlib.Path(logfile).stem
        data[key] = set()
        with open(logfile, 'rt') as stream:
            _read = False
            for line in stream:
                if line.startswith('-- end srcvenn'):
                    _read = False
                if _read:
                    data[key].add(SrcTuple(line))
                if line.startswith('-- begin srcvenn'):
                    _read = True
    from matplotlib import pyplot as plt
    plt.figure()
    if len(data) == 2:
        plot = matplotlib_venn.venn2(tuple(data.values()), set_labels=tuple(data.keys()))
    elif len(data) == 3:
        plot = matplotlib_venn.venn3(tuple(data.values()), set_labels=tuple(data.keys()))
    else:
        raise NotImplementedError('venn list must be in [2, 3]')
    plt.savefig(target)
# --------------------
def _exec_command_extract_timecop(args) -> None:
    tlogs = []
    for logfile in args.log:
        with open(logfile, 'rt') as stream:
            tlogs.append(TimecopLog(logfile, stream.read()))
    sys.stdout.write('-- begin srcvenn\n')
    sys.stdout.write(f'total number of contexts: {sum((len(e.vist) for e in tlogs))}\n')
    for tlog in tlogs:
        tlog.pprint_srcvenn()
    sys.stdout.write('-- end srcvenn\n')
# --------------------
def _exec_command(command: str, args) -> None:
    globals()[f'_exec_command_{command.replace("-", "_")}'](args)
# --------------------
def binsec_utils() -> None:
    ap = ArgumentParser(description='Misc. Binsec Scripting Utils')
    ap.add_argument('-d', '--debug', action='store_true', help='print debug information')
    ap.add_argument('-w', '--workers', action='store', type=int, default=20)
    ap.add_argument('--objdump-parser', action='store', choices=OBJDUMP_PARSERS.keys(), default='fr')

    cmds = ap.add_subparsers(dest='command')

    cmd1 = cmds.add_parser('extract-opcodes')
    cmd1.add_argument('binary', action='store', nargs='+', help='binaries to extract opcodes for')
    cmd1.add_argument('--text-only', action='store_true')

    cmd2 = cmds.add_parser('check-opcodes')
    cmd2.add_argument('binary', action='store', nargs='+', help='binaries to extract opcodes for')
    cmd2.add_argument('-r', '--report', action='store', default='report.yml', help='analysis results')
    cmd2.add_argument('--text-only', action='store_true')
    cmd2.add_argument('--patch', action='store', default=None)

    cmd3 = cmds.add_parser('feedback-run')
    cmd3.add_argument('-r', '--run', action='store', default=None)
    cmd3.add_argument('-f', '--run-file', action='store', default=None)
    cmd3.add_argument('-t', '--run-timeout', action='store', type=int, default=0)
    cmd3.add_argument('--run-timeout-cap', action='store', type=int, default=3600)
    cmd3.add_argument('-g', '--growth-factor', action='store', type=int, default=10)
    cmd3.add_argument('--full-report', action='store_true')
    cmd3.add_argument('--replace-opcode', action='store', nargs='+', default=[])
    cmd3.add_argument('--output-dir', action='store', default='binsec.utils.dir')

    cmd4 = cmds.add_parser('auto-pqc1')
    cmd5 = cmds.add_parser('auto-pqc2')
    for _cmd in (cmd4, cmd5):
        _cmd.add_argument('-r', '--run', action='store', default=None)
        _cmd.add_argument('-f', '--run-file', action='store', default=None)
        _cmd.add_argument('-t', '--run-timeout', action='store', type=int, default=0)
        _cmd.add_argument('--run-timeout-cap', action='store', type=int, default=3600)
        _cmd.add_argument('-g', '--growth-factor', action='store', type=int, default=10)
        _cmd.add_argument('--keep-ct', dest='remove_ct', action='store_false')
        _cmd.add_argument('--keep-ct-secret', dest='remove_ct_secret', action='store_false')
        _cmd.add_argument('--ct-secret-byte', action='store', type=int, default=-1)
        _cmd.add_argument('--full-report', action='store_true')
        _cmd.add_argument('--replace-opcode', action='store', nargs='+', default=[])
        _cmd.add_argument('--replace-function', action='store', nargs='+', default=[])
        _cmd.add_argument('--output-dir', action='store', default='binsec.utils.dir')

    cmd6 = cmds.add_parser('analyze-log')
    cmd6.add_argument('log', action='store', nargs='+')
    cmd6.add_argument('--full-report', action='store_true')
    cmd6.add_argument('-f', '--format', action='store', choices=[fmt.name.lower() for fmt in FeedbackSummaryFormat], default='default')

    cmd7 = cmds.add_parser('make-venn')
    cmd7.add_argument('vennlog', action='store', nargs='+')
    cmd7.add_argument('-o', '--output', action='store', default='venn.pdf')

    cmd8 = cmds.add_parser('extract-timecop')
    cmd8.add_argument('log', action='store', nargs='+')
    # cmd8.add_argument('-o', '--output', action='store', default='timecop.srcvenn.log')

    args = ap.parse_args()
    _logger_init(args)
    BinsecBinaryFile.set_default_parser(OBJDUMP_PARSERS[args.objdump_parser])
    _exec_command(args.command, args)
# --------------------
# --------------------
# --------------------
