# --------------------
import os
import io
import re
import logging
from dataclasses import dataclass, field
from typing import Optional, TypedDict
from typing_extensions import NotRequired
from ._intracore.system import command_exec
# --------------------
class BinsecBinaryLocation(TypedDict):
    binary: str
    loc: int
    mnemo: NotRequired[str]
# --------------------
@dataclass
class BBFOpcode:
    opcode: str
    source: 'BBFInst'

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BBFOpcode):
            return other.__eq__(self)
        return self.opcode.__eq__(other.opcode)

    def __hash__(self) -> int:
        return self.opcode.__hash__()

    def __str__(self) -> str:
        return self.opcode.__str__()
# --------------------
@dataclass
class BBFInst:
    loc: int
    opcode: str
    mnemo: str
    operands: str
    binary: str

    def as_opcode(self) -> BBFOpcode:
        return BBFOpcode(self.opcode.replace(' ', ''), self)
# --------------------
@dataclass
class BBFTextSymbol:
    name: str
    loc: int
    endloc: int
    instructions: list[int] = field(default_factory=list)
# --------------------
@dataclass
class BBFSection:
    name: str
    loc: int
    endloc: int
    symbols: list[int] = field(default_factory=list)
# --------------------
@dataclass
class BBFObjdump:
    sections: dict[str, BBFSection]
    symbols: dict[int, BBFTextSymbol]
    instructions: dict[int, BBFInst]

    def get_section(self, name: str) -> BBFSection:
        if name not in self.sections:
            logging.error('section %s was not found (available: %s)', name, str(self.sections.keys()))
        return self.sections[name]

    def get_symbol(self, name: str) -> BBFTextSymbol:
        candidates = (symbol for symbol in self.symbols.values() if symbol.name == name)
        for candidate in candidates:
            return candidate
        logging.error('no symbol with name %s was found', name)
        raise KeyError(name)
# --------------------
@dataclass
class ObjdumpParser:
    section: str
    symbol: str
    data: str
    instruction: str
    instruction_c: str
# --------------------
DEFAULT_x86_OBJDUMP_PARSER = ObjdumpParser(
    r'Disassembly of section ([._a-zA-Z0-9]+):',
    r'([0-9a-f]+)[ \t]*<([^>]+)>:',
    r'[ \t]*([0-9a-f]+):[ \t]*([0-9a-f]{2})',
    r'^\s*([0-9a-f]{1,}):\s+((?:[0-9a-f]{2}\s)+)\s+(\w+)(.*)',
    r'^\s*([0-9a-f]{1,}):\s+((?:[0-9a-f]{2}\s)+)'
)
DEFAULT_x86_OBJDUMP_PARSER_FR = ObjdumpParser(
    r'Déassemblage de la section ([._a-zA-Z0-9]+)\s*:',
    r'([0-9a-f]+)[ \t]*<([^>]+)>:',
    r'[ \t]*([0-9a-f]+):[ \t]*([0-9a-f]{2})',
    r'^\s*([0-9a-f]{1,}):\s+((?:[0-9a-f]{2}\s)+)\s+(\w+)(.*)',
    r'^\s*([0-9a-f]{1,}):\s+((?:[0-9a-f]{2}\s)+)'
)
OBJDUMP_PARSERS = {
    'core': DEFAULT_x86_OBJDUMP_PARSER,
    'fr': DEFAULT_x86_OBJDUMP_PARSER_FR
}
# --------------------
def create_objdump(target: str, parser: ObjdumpParser) -> BBFObjdump:
    objd = command_exec(['objdump', '-D', target])
    if objd.rv != 0:
        raise OSError(f'objdump failure on file {target}')
    sections: dict[str, BBFSection] = {}
    symbols: dict[int, BBFTextSymbol] = {}
    instructions: dict[int, BBFInst] = {}
    with io.StringIO(objd.out) as stream:
        init_section: Optional[str] = None
        init_symbol: Optional[str] = None
        c_section: Optional[BBFSection] = None
        c_symbol: Optional[BBFTextSymbol] = None
        last_loc = 0
        inst = None
        for line in stream:
            logging.debug(line.strip())
            smatch = re.match(parser.section, line)
            symatch = re.match(parser.symbol, line)
            dmatch = re.match(parser.data, line)
            lmatch = re.match(parser.instruction, line)
            cmatch = re.match(parser.instruction_c, line)
            if smatch:
                if c_section is not None:
                    c_section.endloc = last_loc
                    c_section = None
                init_section = smatch[1]
            if symatch:
                if c_symbol is not None:
                    c_symbol.endloc = last_loc
                    c_symbol = None
                init_symbol = symatch[2]
            if lmatch:
                logging.debug('found instruction %s', line.strip())
                inst = BBFInst(int(lmatch[1], 16), lmatch[2], lmatch[3], lmatch[4], target)
                if inst.loc in instructions:
                    logging.debug('objdump reports several instructions @0x%x -> skipping duplicate', inst.loc)
                    continue
                instructions[inst.loc] = inst
                if c_section is None:
                    if init_section is None:
                        logging.error('access to uninitialized section')
                        raise ValueError(None)
                    c_section = BBFSection(init_section, inst.loc, 0)
                    sections[c_section.name] = c_section
                if c_symbol is None:
                    if init_symbol is None:
                        logging.error('access to uninitialized symbol')
                        raise ValueError(None)
                    c_symbol = BBFTextSymbol(init_symbol, inst.loc, 0)
                    c_section.symbols.append(inst.loc)
                    symbols[inst.loc] = c_symbol
                c_symbol.instructions.append(inst.loc)
            elif cmatch:
                logging.debug('found instruction continuation %s', line.strip())
                if inst is not None:
                    inst.opcode += cmatch[2]
    return BBFObjdump(sections, symbols, instructions)
# --------------------
class BinsecBinaryFile:

    DEFAULT_PARSER = DEFAULT_x86_OBJDUMP_PARSER_FR

    @classmethod
    def set_default_parser(cls, parser: ObjdumpParser):
        cls.DEFAULT_PARSER = parser

    def __init__(self, target: str, parser: Optional[ObjdumpParser] = None):
        if not os.path.isfile(target):
            raise ValueError(target)
        self._path = target
        self._objdump = create_objdump(self._path, parser if parser is not None else self.DEFAULT_PARSER)
        self._opcodes: set[BBFOpcode] = set()
        self._text_opcodes: set[BBFOpcode] = set()

    @property
    def path(self) -> str:
        return self._path

    def opcode(self, addr: int) -> BBFOpcode:
        return self._objdump.instructions[addr].as_opcode()

    @property
    def opcodes(self) -> set[BBFOpcode]:
        if not self._opcodes:
            for loc, inst in self._objdump.instructions.items():
                self._opcodes.add(inst.as_opcode())
        return self._opcodes

    @property
    def text_opcodes(self) -> set[BBFOpcode]:
        if not self._text_opcodes:
            for symbol in self._objdump.get_section('.text').symbols:
                for loc in self._objdump.symbols[symbol].instructions:
                    inst = self._objdump.instructions[loc]
                    self._text_opcodes.add(inst.as_opcode())
        return self._text_opcodes

    def calls_of(self, symbol_name: str) -> tuple[dict[str, int], dict[str, list[int]]]:
        symbol = self._objdump.get_symbol(symbol_name)
        calls = {}
        offsets = {}
        for loc in symbol.instructions:
            inst = self._objdump.instructions[loc]
            if inst.mnemo in ('call',):
                target = re.match(r'\s*([0-9a-z]+)\s<([^>]+)>', inst.operands)
                if target is not None:
                    callee = target[2]  # TODO: Possibily match with symbol name at address target[1]
                    if callee not in calls:
                        calls[callee] = 0
                        offsets[callee] = []
                    calls[callee] += 1
                    offsets[callee].append(loc - symbol.loc)
                else:
                    logging.warning('unrecovered call @%i', inst.loc)
        return calls, offsets
# --------------------
# --------------------
# --------------------
