# --------------------
import logging
import io
from colorama import Fore, Style
from typing import TypedDict, Optional
from typing_extensions import Unpack
# --------------------
class IntraFormatter(logging.Formatter):

    CORE_FORMAT = '{0}: {1}'

    def format(self, record: logging.LogRecord) -> str:
        core = super().format(record)
        result: str = getattr(self, f'intra_{record.levelname.lower()}')(core)
        return result

    def intra_debug(self, core: str) -> str:
        return self.CORE_FORMAT.format('[debug]  ', core)

    def intra_info(self, core: str) -> str:
        return self.CORE_FORMAT.format('[info]   ', core)

    def intra_warning(self, core: str) -> str:
        return self.CORE_FORMAT.format('[warning]', core)

    def intra_error(self, core: str) -> str:
        return self.CORE_FORMAT.format('[error]  ', core)

    def intra_critical(self, core: str) -> str:
        return self.CORE_FORMAT.format('[fatal]  ', core)
# --------------------
class ColoredIntraFormatter(logging.Formatter):

    CORE_FORMAT = '{2}{0}:{4} {3}{1}{5}'

    def format(self, record: logging.LogRecord) -> str:
        core = super().format(record)
        result: str = getattr(self, f'intra_{record.levelname.lower()}')(core)
        return result

    def intra_debug(self, core: str) -> str:
        return self.CORE_FORMAT.format('[debug]  ', core, Style.DIM, Style.DIM, Style.RESET_ALL, Style.RESET_ALL)

    def intra_info(self, core: str) -> str:
        return self.CORE_FORMAT.format('[info]   ', core, Fore.CYAN, '', Style.RESET_ALL, '')

    def intra_warning(self, core: str) -> str:
        return self.CORE_FORMAT.format('[warning]', core, Fore.YELLOW + Style.BRIGHT, Fore.YELLOW, Style.RESET_ALL, Style.RESET_ALL)

    def intra_error(self, core: str) -> str:
        return self.CORE_FORMAT.format('[error]  ', core, Fore.RED + Style.BRIGHT, Fore.RED, Style.RESET_ALL, Style.RESET_ALL)

    def intra_critical(self, core: str) -> str:
        return self.CORE_FORMAT.format('[fatal]  ', core, Fore.MAGENTA + Style.BRIGHT, Fore.MAGENTA, Style.RESET_ALL, Style.RESET_ALL)
# --------------------
class _LocationArgsDict(TypedDict, total=False):
    startl: int
    startc: int
    endl: int
    endc: int
    start: int
    end: int
# --------------------
class TextLocation:
    def __init__(self, **kwargs: Unpack[_LocationArgsDict]):
        startl, startc = kwargs.get('startl', 0), kwargs.get('startc')
        endl, endc = kwargs.get('endl', 0), kwargs.get('endc')
        start, end = kwargs.get('start', 0), kwargs.get('end', 0)
        self.startl = startl
        self.startc = startc if startc is not None else start
        self.endl = endl
        self.endc = endc if endc is not None else end

    def __str__(self) -> str:
        return f'{self.startl}, {self.startc} -> {self.endl}, {self.endc}'
# --------------------
class TextLocatedError(Exception):
    def __init__(self, loc: TextLocation, *args):
        super().__init__(*args)
        self.loc = loc

    def pretty_msg(self, source:  Optional[str] = None, colored: bool = False) -> str:
        result = io.StringIO()
        result.write(f'{Fore.RED if colored else ""}{Style.BRIGHT if colored else ""}'
                     f'Text Located Error: {Style.NORMAL if colored else ""}'
                     f'at line {self.loc.startl}:{self.loc.startc}{Style.RESET_ALL if colored else ""}\n\n')
        slines = source.split('\n') if source is not None else []
        lsi, lse = max(0, self.loc.startl - 1), min(len(slines) - 1, self.loc.endl - 1)
        lin, lou = slines[lsi], slines[lse]
        if lsi >= lse:
            result.write(f' {lin[:self.loc.startc-1]}{Fore.RED if colored else ""}'
                         f'{lin[self.loc.startc-1:self.loc.endc-1]}{Style.RESET_ALL if colored else ""}'
                         f'{lin[self.loc.endc-1:]}\n')
        else:
            result.write(f' {lin[:self.loc.startc-1]}{Fore.RED if colored else ""}{lin[self.loc.startc-1:]}\n')
            for i in range(lsi + 1, lse):
                result.write(f' {slines[i]}\n')
            result.write(f' {lou[:self.loc.endc-1]}{Style.RESET_ALL if colored else ""}{lou[self.loc.endc-1:]}\n')
        result.write(f'{Fore.RED if colored else ""}{Style.BRIGHT if colored else ""} --- {self}\n')
        return result.getvalue()
# --------------------
