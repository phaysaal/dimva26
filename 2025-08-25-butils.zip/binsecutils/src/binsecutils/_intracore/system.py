# --------------------
import os
import sys
from typing import Optional
from subprocess import Popen, STDOUT, PIPE, TimeoutExpired
# --------------------
class ExecResult:

    def __init__(self, rv: int, to: bool, out: str, err: str):
        self.rv: int = rv
        self.to: bool = to
        self.out: str = out
        self.err: str = err
# --------------------
def command_exec(cmd: list[str], timeout: Optional[int] = None,
                 stdin: Optional[str] = None, merge: bool = True) -> ExecResult:
    stdin_enc = stdin.encode('utf-8') if stdin is not None else None
    proc = Popen(cmd, stdout=PIPE, stderr=(STDOUT if merge else PIPE), stdin=(PIPE if stdin_enc is not None else None))
    to = False
    try:
        cout, cerr = proc.communicate(timeout=timeout, input=stdin_enc)
    except TimeoutExpired:
        to = True
        proc.terminate()
        #proc.kill()
        cout, cerr = proc.communicate()
    return ExecResult(proc.returncode, to,
                      cout.decode(sys.stdout.encoding, errors='ignore'),
                      cerr.decode(sys.stderr.encoding, errors='ignore') if cerr is not None else None)
# --------------------
def path_command_exec(cmd: list[str], path: str, timeout: Optional[int] = None,
                      stdin: Optional[str] = None, merge: bool = True) -> ExecResult:
    cwd = os.getcwd()
    os.chdir(path)
    res = command_exec(cmd, timeout=timeout, stdin=stdin, merge=merge)
    os.chdir(cwd)
    return res
# --------------------
