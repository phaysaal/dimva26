## Install

`pip3 install .` or `pipx install.`

## Extract opcodes from a list of binaries:

`binsec-utils extract-opcodes --text-only BINARY1 [BINARY2 ...]`

## Check if binsec handles the opcodes of a list of binaries:

*(Requires a `binsec` install; results match `binsec disasm-decode`)*

`binsec-utils check-opcodes --text-only BINARY1 [BINARY2 ...]`
